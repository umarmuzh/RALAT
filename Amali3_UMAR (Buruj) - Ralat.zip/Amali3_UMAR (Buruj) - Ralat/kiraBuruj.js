function paparBuruj {

    var hari = parseFloat(document.getElementByid("hari").value);
    var bulan = parseFloat(document.getElementById("bulan").value);

    if (isNaN(hari) || isNaN(bulan) || hari < 1 || hari > 31 || bulan < 1 || bulan > 12) {
        alert("ruang kosong TIDAK DIBENARKAN!");
        return;
    }

    var penyataan;
    var ikon;

    if ((bulan === 3 && hari >= 21) || (bulan === 4 && hari <= 19)) {
        penyataan = "Aries";
        ikon = "aries.png";
    } 
    else if ((bulan === 4 && hari >= 20) || (bulan === 5 && hari <= 20)) {
        penyataan = "Taurus";
        ikon = "taurus.png";
    } 
    else if ((bulan === 5 && hari >= 21) || (bulan === 6 && hari <= 20)) {
        penyataan = "Gemini";
        ikon = "gemini.png";
    } 
    else if ((bulan === 6 && hari >= 21) || (bulan === 7 && hari <= 22)) {
        penyataan = "Cancer";
        ikon = "cancer.png";
    } 
    else if ((bulan === 7 && hari >= 23) || (bulan === 8 && hari <= 22)) {
        penyataan = "Leo";
        ikon = "leo.png";
    } 
    else if ((bulan === 8 && hari >= 23) || (bulan === 9 && hari <= 22)) {
        penyataan = "Virgo";
        ikon = "virgo.png";
    } 
    else if ((bulan === 9 && hari >= 23) || (bulan === 10 && hari <= 22)) {
        penyataan = "Libra";
        ikon = "libra.png";
    } 
    else if ((bulan === 10 && hari >= 23) || (bulan === 11 && hari <= 21)) {
        penyataan = "Scorpio";
        ikon = "scorpio.png";
    } 
    else if ((bulan === 11 && hari >= 22) || (bulan === 12 && hari <= 21)) {
        penyataan = "Sagittarius";
        ikon = "sagittarius.png";
    } 
    else if ((bulan === 12 && hari >= 22) || (bulan === 1 && hari <= 19)) {
        penyataan = "Capricorn";
        ikon = "capricorn.png";
    } 
    else if ((bulan === 1 && hari >= 20) || (bulan === 2 && hari <= 18)) {
        penyataan = "Aquarius";
        ikon = "aquarius.png";
    } 
    else {
        penyataan = "Pisces";
        ikon = "pisces.png";
    }
    
    if (penyataan) {
        document.getElementById("penyataan").innerHTML = "Buruj anda ";
        document.getElementById("ikon").src = ikon;
        document.getElementById("ikon").style.display = "block";
    } else {
        alert("Tiada buruj yang ditemui untuk tarikh kelahiran ini.");
    }
}